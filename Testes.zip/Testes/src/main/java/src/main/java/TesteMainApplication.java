package src.main.java;


public class TesteMainApplication {

    public static void main(String[] args) {

        String a = ".W.\n"+
                ".W.\n"+
                "...";


        System.out.println(a);




    }
}
